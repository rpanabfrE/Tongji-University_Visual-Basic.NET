﻿Public Class Form1

    Dim n%

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "2350450"    '将窗体的标题设置为我的学号
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim pay% = 0        '数据初始化
        Dim tian% = Val(TextBox1.Text)    '天数

        If RadioButton1.Checked Then
            pay = 200 * tian
        Else
            pay = 300 * tian
        End If

        If CheckBox1.Checked Then pay += 60
        If CheckBox2.Checked Then pay += 80

        TextBox2.Text = pay
    End Sub

    Private Sub HScrollBar1_Scroll(sender As Object, e As ScrollEventArgs) Handles HScrollBar1.Scroll
        If RadioButton3.Checked Then
            TextBox3.Text = ""
            n = HScrollBar1.Value
            For i = n To 1 Step -1
                TextBox3.Text &= StrDup(2 * i - 1, Chr(71 - i)) & vbCrLf
            Next
            For i = 2 To n
                TextBox3.Text &= StrDup(2 * i - 1, Chr(71 - i)) & vbCrLf
            Next
        Else
            TextBox3.Text = ""
            n = HScrollBar1.Value
            For i = n To 1 Step -1
                TextBox3.Text &= StrDup(2 * i - 1, Chr(55 - i)) & vbCrLf
            Next
            For i = 2 To n
                TextBox3.Text &= StrDup(2 * i - 1, Chr(55 - i)) & vbCrLf
            Next
        End If
    End Sub
End Class
