﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim s, c As String
        Dim i, n, h As Integer

        s = UCase(TextBox1.Text)
        n = Len(s)
        i = 1

        Do While i <= n
            c = Mid(s, i, 1)
            If c >= "0" And c <= "9" Then
                h = h * 16 + 16 ^ Val(c)
            ElseIf c >= "A" And c <= "F" Then
                Dim m = Asc(c)
                h = h * 16 + 16 ^ (m - 55)
            End If
            i += 1
        Loop

        Label1.Text = "十进制：" & h
    End Sub
End Class
