﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim x, y As Single    '数据类型定义错误，不应当定义为整型，已改正
        x = Val(TextBox1.Text)
        y = x * 2.54
        Label1.Text = "结果为：" & y & "厘米 "    '字符串连接符使用错误，应当使用&而非+    已改正
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim s As Integer
        s = Mid(TextBox2.Text, 5, 2)    'Mid函数少了第三个参数。已改正
        If s <= 3 Then
            Label2.Text = "春天！"
        ElseIf 3 < s And s <= 6 Then    '表达式不能使用连等。已改正
            Label2.Text = "夏天！"
        ElseIf s <= 9 And s > 6 Then
            Label2.Text = "秋天！"
        ElseIf s <= 12 And s >= 9 Then    '应当使用And而非Or，已改正
            Label2.Text = "冬天！"
        Else
            Label2.Text = "月份数字有误!"
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim n, i As Integer
        Dim x As Integer
        If IsNumeric(TextBox3.Text) Then    '判断是否为数字应当使用IsNumeric函数，而非Len函数，已改正
            n = Val(TextBox3.Text)
            For i = 1 To n
                x = x * 10 + i    '算式写错，已改正
            Next
            For i = n - 1 To 1 Step -1    '少写了步长，已改正
                x = x * 10 + i
            Next
            Label3.Text = x
        Else
            Label3.Text = "请输入数字"
        End If
    End Sub
End Class
