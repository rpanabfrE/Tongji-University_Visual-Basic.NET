﻿Imports System.Math
Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim mark() As Integer = {71, 53, 58, 29, 30, 78}
        Dim s As String = "★★★★★★★★★★★★★★★★★★★★★"

        For i = 0 To 5
            Label1.Text &= Mid(s, 1, Math.Round(mark(i) / 5)) & mark(i) & vbCrLf & vbCrLf
        Next
    End Sub
End Class
